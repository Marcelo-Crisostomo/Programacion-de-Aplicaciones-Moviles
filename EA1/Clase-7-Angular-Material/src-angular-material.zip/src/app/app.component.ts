import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  //Variable para mostrar el mensaje
  mensaje: string = 'Presiona el botón para ver el mensaje oculto';

  //Función para mostrar el mensaje 
  mostrarMensaje(){
    this.mensaje = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris risus diam, dictum in tellus vel, maximus vehicula metus. Fusce tempor, lorem a scelerisque rutrum, tellus metus luctus tellus, et interdum lorem dolor condimentum elit. Nam sit amet massa luctus, laoreet enim pretium, rhoncus odio. Suspendisse ac metus a diam eleifend tempus. Ut aliquam ac nulla quis dictum. Donec bibendum pellentesque quam, pellentesque elementum tortor sollicitudin vel. Aenean ante libero, finibus id orci sit amet, pretium pulvinar nunc. Donec dictum justo rutrum dictum porttitor. Aliquam vel purus ut quam porta aliquam ut nec mi. In vestibulum quam eget odio malesuada efficitur. Mauris imperdiet, purus sed sagittis porttitor, diam lorem varius nunc, interdum mattis libero ante non felis. Nulla finibus semper lorem, eget sagittis turpis iaculis at.'

  }

  constructor() {}
}
