import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  constructor() {}
  //variable para mostrar el menmsaje
  mensaje: string = 'Presiona el botón para ver el mensaje';

  //Función para actualizar el mensaje
  mostrarMensaje(){
    this.mensaje = 'Hola este es el mensaje del botón';
  }
}
