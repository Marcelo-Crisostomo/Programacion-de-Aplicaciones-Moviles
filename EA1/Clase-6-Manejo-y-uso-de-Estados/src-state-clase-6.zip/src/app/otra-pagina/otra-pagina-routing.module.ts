import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { OtraPaginaPage } from './otra-pagina.page';

const routes: Routes = [
  {
    path: '',
    component: OtraPaginaPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class OtraPaginaPageRoutingModule {}
