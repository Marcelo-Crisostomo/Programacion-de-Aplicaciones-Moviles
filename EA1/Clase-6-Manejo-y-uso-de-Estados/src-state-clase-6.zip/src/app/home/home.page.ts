import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { EstadoService } from '../servicios/estado.service';//Importando el servicio creado
@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  contador: number=0;//variable para el contador
  
  constructor(private estadoService: EstadoService, private router:Router ) {}
  ngOnInit(){
    console.log('ngOnInit el componente se ha inicializado');
    //vamos a suscribir al observable para recibir las actualizaciones de la variable.
    this.estadoService.contadorActual.subscribe(valor=>{
      this.contador=valor;
      console.log('ngOnInit Contador actualizado', this.contador );
    });
  }
  //Se ejecuta justo antes que la vista se muestre.
  ionViewWillEnter(){
    console.log('Se ejecuta justo antes que la vista se muestre')
    console.log('ionViewWillEnter', this.contador );
  }

    //Se ejecuta cuando la vista está completamente cargada
    ionViewDidEnter(){
      console.log('Se ejecuta cuando la vista está completamente cargada')
      console.log('ionViewDidEnter', this.contador );
    }
        //Se ejecuta cuando la vista está a punto de desaparecer
        ionViewWillLeave(){
          console.log('Se ejecuta cuando la vista está a punto de desaparecer')
          console.log('ionViewWillLeave', this.contador );
        }
        //Se ejecuta cuando la vista desaparece por completo
        ionViewDidLeave(){
          console.log('Se ejecuta cuando la vista desaparece por completo')
          console.log('ionViewDidLeave', this.contador );
        }
        //Se ejecuta cuando el componente está a punto de ser destruido
        ngOnDestroy(){
          console.log('Se ejecuta cuando el componente está a punto de ser destruido')
          console.log('ngOnDestroy', this.contador );
        }
        //Método para incrementarthi
        incrementarContador(){
          this.estadoService.incrementar();
        }
        //Método para disminuir
        decrementarContador(){
          this.estadoService.decrementar();
        }
        //Navegar hacia otra página
        navegarAOtraPagina(){
          this.router.navigate(['otra-pagina']);
        }


}
