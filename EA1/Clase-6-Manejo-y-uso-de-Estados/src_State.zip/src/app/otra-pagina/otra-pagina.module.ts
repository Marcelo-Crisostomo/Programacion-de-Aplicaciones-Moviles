import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { OtraPaginaPageRoutingModule } from './otra-pagina-routing.module';

import { OtraPaginaPage } from './otra-pagina.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    OtraPaginaPageRoutingModule
  ],
  declarations: [OtraPaginaPage]
})
export class OtraPaginaPageModule {}
