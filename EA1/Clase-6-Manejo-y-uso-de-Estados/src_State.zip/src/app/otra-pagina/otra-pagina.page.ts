import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-otra-pagina',
  templateUrl: './otra-pagina.page.html',
  styleUrls: ['./otra-pagina.page.scss'],
})
export class OtraPaginaPage implements OnInit {

  constructor(private router:Router) { }

  regresar(){
    this.router.navigate(['/home']);
  }


  ngOnInit() {
  }

}
