import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';//Para trabajar de manera reactiva

@Injectable({
  providedIn: 'root'
})
export class EstadoService {
  ///Contador inicializado en 0
  private contador = new BehaviorSubject<number>(0);

  //Observa la variable para poder suscribirla
  contadorActual = this.contador.asObservable();
  constructor() { }
  //Métodos
  //Incrementar el númerillo
  incrementar(){
    this.contador.next(this.contador.value + 1);
  }
   //disminuir el númerillo
   decrementar(){
    this.contador.next(this.contador.value - 1);
  }
  //Reiniciar el contador en 0
  reiniciarContador(){
    this.contador.next(0);
  }
}
