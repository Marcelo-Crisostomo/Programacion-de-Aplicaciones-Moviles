import { Component, OnInit } from '@angular/core';
import { AnimationController } from '@ionic/angular';////////
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent implements OnInit { ////
  constructor(private animacionCtrl: AnimationController) {}///////private animacionCtrl: AnimationControlle


  ngOnInit() {/////////////////////////////////77
    this.animarTexto(); // ### Inicia la animación del texto al cargar la página
    this.animarIcono(); // ### Inicia la rotación del ícono al cargar la página
  }

   // ### Método para animar el botón
   animarBoton() {
    const boton = document.querySelector('.boton-animado');  // ### Selecciona el botón por su clase

    if (boton) {
      const animacion = this.animacionCtrl.create()
        .addElement(boton)  // ### Aplica la animación al botón
        .duration(500)  // ### Duración de la animación (500 ms)
        .fromTo('transform', 'scale(1)', 'scale(1.2)')  // ### Aumenta el tamaño del botón
        .fromTo('background-color', '#3880ff', '#ff5722');  // ### Cambia el color de azul a naranja

      animacion.play();  // ### Ejecuta la animación
    } else {
      console.error('No se pudo encontrar el botón con la clase .boton-animado');
    }
  }

   // ### Método para rotar el ícono
   animarIcono() {
    const icono = document.querySelector('.icono-rotativo');  // ### Selecciona el ícono por su clase

    if (icono) {
      const animacion = this.animacionCtrl.create()
        .addElement(icono)  // ### Aplica la animación al ícono
        .duration(2000)  // ### Duración de la rotación (2 segundos)
        .iterations(Infinity)  // ### Repite indefinidamente
        .fromTo('transform', 'rotate(0deg)', 'rotate(360deg)');  // ### Rota el ícono 360 grados

      animacion.play();  // ### Ejecuta la animación
    } else {
      console.error('No se pudo encontrar el ícono con la clase .icono-rotativo');
    }
  }

  // ### Método para deslizar la tarjeta
  animarTarjeta() {
    const tarjeta = document.querySelector('.tarjeta-animada');  // ### Selecciona la tarjeta por su clase

    if (tarjeta) {
      const animacion = this.animacionCtrl.create()
        .addElement(tarjeta)  // ### Aplica la animación a la tarjeta
        .duration(1000)  // ### Duración de la animación (1 segundo)
        .fromTo('transform', 'translateX(-100%)', 'translateX(0%)')  // ### Desliza la tarjeta desde la izquierda
        .fromTo('opacity', '0', '1');  // ### Cambia la opacidad de 0 a 1

      animacion.play();  // ### Ejecuta la animación
    } else {
      console.error('No se pudo encontrar la tarjeta con la clase .tarjeta-animada');
    }
  }

  // ### Método para desvanecer el texto
  animarTexto() {
    const texto = document.querySelector('.texto-desvanecido');  // ### Selecciona el texto por su clase

    if (texto) {
      const animacion = this.animacionCtrl.create()
        .addElement(texto)  // ### Aplica la animación al texto
        .duration(1500)  // ### Duración del desvanecimiento (1.5 segundos)
        .fromTo('opacity', '0', '1');  // ### Cambia la opacidad de 0 a 1

      animacion.play();  // ### Ejecuta la animación
    } else {
      console.error('No se pudo encontrar el texto con la clase .texto-desvanecido');
    }
  }

}


