import { Superheroe } from './superheroe';

describe('Superheroe', () => {
  it('should create an instance', () => {
    expect(new Superheroe()).toBeTruthy();
  });
});
