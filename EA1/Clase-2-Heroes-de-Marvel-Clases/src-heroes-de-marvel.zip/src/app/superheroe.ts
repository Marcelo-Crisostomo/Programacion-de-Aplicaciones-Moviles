export class Superheroe {
    constructor(
        public id: number, //Id del hero
        public nombre: string
    ){}
}
