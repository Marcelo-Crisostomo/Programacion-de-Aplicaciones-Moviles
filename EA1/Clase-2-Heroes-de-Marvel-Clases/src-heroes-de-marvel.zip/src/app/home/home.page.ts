import { Component } from '@angular/core';
import { Superheroe } from '../superheroe';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  //título de mi aplicación
  titulo = 'Superhéros de Marvel'

  superheroes = [
    new Superheroe(1, 'Capitán América'),
    new Superheroe(2, 'Iron Man'),
    new Superheroe(3, 'Spiderman'),
    new Superheroe(4, 'Thor')
  ]
  miSuperheroe = this.superheroes[0];

  constructor() {}

}
