import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';//##########
//definimos el componente de Angular
@Component({
  selector: 'app-login',//nombre
  templateUrl: './login.page.html',//La url del template HTML
  styleUrls: ['./login.page.scss'],//La URL de los estilos de la página
})
export class LoginPage implements OnInit {

  //Almacenamos el nombre del usuario y el password en una variable
  username: string = '';
  password: string = '';
  constructor(private router:Router) { }
  /*
    El constructor de la clase recibe una instancia de `Router` como un parámetro inyectado.
    - `private router: Router` define una propiedad privada `router` que se inicializa con la instancia del `Router` inyectado.
    - Esta inyección permite a la clase utilizar el `Router` para realizar la navegación programática dentro de la aplicación.
  */
  login(){
    /*== (igualdad débil): Compara los valores después de convertirlos al mismo tipo si es necesario (coerción de tipo). Por ejemplo, 5 == "5" es true porque el string "5" se convierte en número antes de comparar.
=== (igualdad estricta): Compara tanto el valor como el tipo sin realizar ninguna conversión. Por ejemplo, 5 === "5" es false porque un número y un string no son del mismo tipo.*/
    //Verificamos que el usuario y la contraseña cumplan los requisitos
    if (this.username.length >=3 && this.username.length <=8 && this.password.length ===4){
      //Navega a la página de inicio si es necesario
      this.router.navigate(['/inicio'],{
        queryParams: {username: this.username}
      });
      /*
        Si las validaciones son exitosas, la aplicación navega a la página de inicio (`/inicio`).
        - `this.router.navigate(['/inicio'], { queryParams: { username: this.username } });` usa el `Router` para navegar a la ruta `/inicio`.
        - `queryParams: { username: this.username }` pasa el nombre de usuario como un parámetro de consulta en la URL. Esto permite que la siguiente página acceda al nombre de usuario si lo necesita.
      */
    }else{
      //Muestra un mensaje de error si las condiciones no se cumplen
      alert ('Usuario o contraseña invalidos')
    }
  }
  ngOnInit() {
  }

}
