import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';//####

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.page.html',
  styleUrls: ['./inicio.page.scss'],
})
export class InicioPage implements OnInit {

  //Variables de la página rescatados //por que el username no usa camelcase?
  username: string ='';
  firstName: string = '';
  lastName: string = '';
  educationLevel: string = '';
  birthDate: string = '';

  constructor(private route: ActivatedRoute) { }

  ngOnInit() {//preguntar que codigo coloco aca y por que ngOnInit()
    this.route.queryParams.subscribe(params =>{
      if (params['username']){
        this.username = params['username'];
      }
    });
  }

  clear(){
    //limpia todos los campos
    this.firstName = '';
    this.lastName = '';
    this.educationLevel = '';
    this.birthDate = '';
  }
  show(){
    //Muestra el nombre y el apellido en un mensaje emergente
    alert( `Nombre :  ${this.firstName} \n Apellido : ${this.lastName}`);
  }

}
