import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

/*
  Aquí se importan los módulos necesarios para configurar el enrutamiento en la aplicación Angular:
  - `NgModule` es el decorador que define un módulo de Angular.
  - `PreloadAllModules` es una estrategia de precarga que carga todos los módulos de manera anticipada después de que se carga la aplicación, mejorando el rendimiento.
  - `RouterModule` es el módulo que contiene las directivas de enrutamiento de Angular y provee el servicio de enrutamiento.
  - `Routes` es una interfaz que define cómo se deben configurar las rutas de la aplicación.
*/

const routes: Routes = [
  {
    path: '',
    // Cuando el camino (path) es una cadena vacía, significa que es la raíz del sitio (por ejemplo, http://localhost:4200/).
    redirectTo: 'login',
    // Se redirige automáticamente a la ruta 'login'.
    pathMatch: 'full'
    // `pathMatch: 'full'` indica que la redirección debe ocurrir solo si toda la URL coincide con la cadena vacía (es decir, cuando la URL está completamente vacía).
  },
  {
    path: 'login',
    // Esta es la ruta para la página de login. Cuando la URL es `http://localhost:4200/login`, esta ruta se activa.
    loadChildren: () => import('./login/login.module').then(m => m.LoginPageModule)
    // `loadChildren` es utilizado para cargar perezosamente (lazy load) el módulo asociado a la página de login.
    // `import('./login/login.module')` importa dinámicamente el módulo del login.
    // `.then(m => m.LoginPageModule)` asegura que se cargue el módulo `LoginPageModule` cuando se accede a esta ruta.
  },
  {
    path: 'inicio',
    // Esta es la ruta para la página de inicio. Cuando la URL es `http://localhost:4200/inicio`, esta ruta se activa.
    loadChildren: () => import('./inicio/inicio.module').then(m => m.InicioPageModule)
    // Similar a la ruta anterior, esta configuración carga perezosamente el módulo `InicioPageModule`.
  },
];

/*
  Estas son las rutas definidas para la aplicación. 
  - La primera ruta redirige a la página de login si la URL está vacía.
  - Las otras rutas cargan perezosamente los módulos de login e inicio cuando se navega a esas rutas.
*/

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
    // `RouterModule.forRoot(routes)` configura las rutas principales para la aplicación.
    // `{ preloadingStrategy: PreloadAllModules }` indica que todos los módulos deben precargarse después de que se cargue la aplicación.
  ],
  exports: [RouterModule]
  // `exports: [RouterModule]` permite que el módulo de enrutamiento esté disponible en toda la aplicación.
})
export class AppRoutingModule { }
// Esta es la clase del módulo de enrutamiento principal de la aplicación.

