import { Component, OnInit } from '@angular/core';
import { LocalStorageService } from '../services/local-storage.service';


@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit {

  //Declarar las variables que voy a guardar
  nombreUsuario: string ="";
  // | operador ts que funciona como un conector
  // mi variable puede tener un valor de tipo number o null
  edadUsuario: number | null = null;

  constructor(private LocalStorageService: LocalStorageService ) {}

  ngOnInit() {
     this.obtenerDatos(); 
  }

  //función guardar datos
guardarDatos(){
  this.LocalStorageService.guardarDato('nombre', this.nombreUsuario);
  this.LocalStorageService.guardarDato('edad', this.edadUsuario);


}

  //funcion obtener datos || = OR 
  obtenerDatos(){
    this.nombreUsuario = this.LocalStorageService.obtenerDato('nombre') || 'no existe un nombre';
    this.edadUsuario = this.LocalStorageService.obtenerDato('edad')||0;
    console.log('Datos obtenidos', this.nombreUsuario, this.edadUsuario);
  }

  //función para limpiar los datos
  limpiarDatos(){
    this.LocalStorageService.limpiarLocalStorage();
    console.log('datos limpiados del LS');
  }


}
