import { Injectable } from '@angular/core';//Servicio va a ser ijectable desde cualquier lugar del proyecto

@Injectable({
  providedIn: 'root'
})
export class LocalStorageService {

  constructor() { }

  //Función para guardar datos en LS
  guardarDato(clave: string, valor:any){//representa un dato de cualquier tipo
    localStorage.setItem(clave, JSON.stringify(valor));//Encadenar un dato number a una cadena de texto 
  }

  //Función para obtener los datos LS
  obtenerDato(clave: string){
    //variable para almacenar ese dato
    const valor = localStorage.getItem(clave);
    //?: if else 
    //Si la respuesta es true devuelve el valor
    //false retorna un null.
    //clave: nombre : marcelo
    return valor ? JSON.parse(valor) : null;
    //paseamos a su valor original
  }
  //Función para eliminar datos de LS
  eliminarDato(clave: string){
    localStorage.removeItem(clave);
    console.log("El dato fue eliminado");
  }
  //Función para limpiar todos los datos de LS
  limpiarLocalStorage(){
    localStorage.clear();
  }
}
