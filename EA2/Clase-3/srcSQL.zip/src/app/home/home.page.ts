import { Component, OnInit } from '@angular/core';
import { StorageService } from '../services/storage.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})


export class HomePage implements OnInit {
  //3 variables para almacena el nombre, edad y la lista de usuarios

  nombreUsuario: string = "";//almacena el nombre del usuario
  edadUsuario: number | null = null;//almacena la edad
  usuarios: Array<{nombre: string, edad: number }>= [];//almacena mi Lista de usuarios
  constructor(private storage:StorageService ) {}
  //Una vez cargue el componente // inicializo el almacen
  ngOnInit() {
      this.obtenerUsuario();
  }
  //1- Función para agregar un usuario a la lista
  async agregarUsuario(){
    const nuevoUsuario = { nombre: this.nombreUsuario, edad: this.edadUsuario || 0 };
  //agrego el usuario al final de la lista  
  this.usuarios.push(nuevoUsuario);
  await this.storage.setUsuarios(this.usuarios);
  console.log("usuario guardado");
  }
  //2- Función para obtener
  async obtenerUsuario(){
    this.usuarios = await this.storage.getUsuarios() || [];
    console.log("usuarios obtenidos", this.usuarios);
  }
  //3 - Función para limpiar los datos
  async limpiarDatos(){
    await this.storage.clearStorage();
    this.usuarios = [];
    console.log("Almacen vacío");
  }
}
